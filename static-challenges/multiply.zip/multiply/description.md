# challenge description
Multiplication is important mkay.
Show us what you got

# soos
- multiplikation ist inverse division
- multiplikation ist quasi ne rekursive addition sheeesh
- das mitochondrium ist das powerhouse der zelle
