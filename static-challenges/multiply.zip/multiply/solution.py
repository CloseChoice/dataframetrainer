def solution(a, b):
    """This function should produce the product of a and b"""
    return a * b